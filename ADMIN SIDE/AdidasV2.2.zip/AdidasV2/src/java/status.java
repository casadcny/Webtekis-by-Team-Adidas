
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Kupal
 */
public class status extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        String status = request.getParameter("changeStatus");
        String idno = request.getParameter("idno");
        PrintWriter pw = response.getWriter();

        
        if(status.equalsIgnoreCase("APPROVE")){
            try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/webtek", "root" , "");
                   String query = "UPDATE users set status=? where idno=?";
                   PreparedStatement pst = (PreparedStatement) conn.prepareStatement(query);
                   
                   pst.setString(1, "approved");
                   pst.setString(2, idno);
                   
                   int rs = pst.executeUpdate();
                   
                    if(rs > 0){
                        response.sendRedirect("home.jsp");
                    }
                   
            } catch (Exception ex) {
                Logger.getLogger(status.class.getName()).log(Level.SEVERE, null, ex);
            }
               
        } else if (status.equalsIgnoreCase("BLOCK")) {
             try {
                Class.forName("com.mysql.jdbc.Driver");
                Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/webtek", "root" , "");
                   String query = "UPDATE users set status=? where idno=?";
                   PreparedStatement pst = (PreparedStatement) conn.prepareStatement(query);
                   
                   pst.setString(1, "pending");
                   pst.setString(2, idno);
                   
                   int rs = pst.executeUpdate();
                   
                    if(rs > 0){
                        response.sendRedirect("home.jsp");
                    }
                   
            } catch (Exception ex) {
                Logger.getLogger(status.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
            
        
    }



}
