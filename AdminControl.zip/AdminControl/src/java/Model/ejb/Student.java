/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model.ejb;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.sql.DataSource;

/**
 *
 * @author Gian Dumpit
 */
@Stateless
public class Student {
    @Resource(name = "jdbc/studentDB")
    private DataSource ds;
    
    public void addStudent(Student student) {
        String sql = "INSERT INTO STUDENT VALUES('"+ student.getStudentID() +"', '"+ student.getName() + "', '"+ student.getAddress() +"')";
        executeModifyQuery(sql);
    }
    public void editStudent(Student student) {
        String sql = "UPDATE STUDENT SET NAME='"+ student.getName() +"', ADDRESS= '"+ student.getAddress() +"' WHERE STUDENTID='"+ student.getStudentID() +"'";
        executeModifyQuery(sql);
    }
    public void deleteStudent(Student student) {
        String sql = "DELETE FROM STUDENT WHERE STUDENTID'"+ student.getStudentID() +"'";
        executeModifyQuery(sql);
    }
    public Student getStudent(String id){
        Student student = new Student();
        String sql = "SELECT * FROM STUDENT WHERE STUDENTID='"+ id +"'";
        System.out.println(sql);
        ResultSet rs = executeFetchQuery(sql);
        try{
            if (rs.next()){
                student.setStudentID(rs.getString("STUDENTID"));
                student.setName(rs.getString("NAME"));
                student.setAddress(rs.getString("ADDRESS"));
            }
        } catch (Exception e) {
            System.err.println("GS" + e.getMessage());
        }
        return student;
    }
    public ArrayList<Student> getAllStudent(){
        ArrayList<Student> list = new ArrayList<Student>();
        String sql = "SELECT * FROM STUDENT";
        ResultSet rs =  executeFetchQuery(sql);
        try {
            while(rs.next()){
                Student student = new Student();
                student.setStudentID(rs.getString("STUDENTID"));
                student.setName(rs.getString("NAME"));
                student.setAddress(rs.getString("ADDRESS"));
                list.add(student);
            }
        } catch (SQLException e){
            System.err.println(e.getMessage());
        }
        return list;
    }
    
    public void executeModifyQuery(String sql){
        try {
            Connection conn = ds.getConnection();
            conn.createStatement().execute(sql);
            conn.close();
        } catch (Exception e) {
            System.err.printl(e.getMessage());
        }
    }
    
    public ResultSet executeFetchQuery(String sql){
        try {
            Connection conn = ds.getConnection();
            rs = conn.createStatement().executeQuery(sql);
            conn.close();
        } catch (Exception e) {
            System.err.printl(e.getMessage());
        }
        return rs;
    }
}
