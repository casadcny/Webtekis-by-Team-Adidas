
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Kupal
 */
public class delete extends HttpServlet {

   
  
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String delete = request.getParameter("delete");
        
        PrintWriter pw = response.getWriter();
        
        try{
            
                Class.forName("com.mysql.jdbc.Driver");
                   Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/socialnetwork", "root" , "");
                   String query = "Delete from user where idno=?";
                   PreparedStatement pst = (PreparedStatement) conn.prepareStatement(query);
                   pst.setString(1, delete);
                   
                   int rs = pst.executeUpdate();
                   if(rs > 0){
                       response.sendRedirect("home.jsp");
                   }else{
                       System.out.println("Error");
                   }
                   
                 
            
        } catch (Exception ex) {
            Logger.getLogger(delete.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
}
